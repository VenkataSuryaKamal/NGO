<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit;
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "educate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve membership details for the logged-in user
$username = $_SESSION['username']; // Assuming username is stored in session
$sql = "SELECT * FROM volunteer_application_form WHERE email = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch membership details
    $row = $result->fetch_assoc();
    $membershipType = isset($row['membership_title']) ? $row['membership_title'] : 'N/A';
    $paymentId = isset($row['payment_id']) ? $row['payment_id'] : 'N/A';
    $timestamp = isset($row['timestamp']) ? $row['timestamp'] : 'N/A';
    $startDate = isset($row['membership_start_date']) ? $row['membership_start_date'] : null;
    $endDate = isset($row['membership_expiry_date']) ? $row['membership_expiry_date'] : 'N/A';

    // Check if membership has expired
    $currentDate = date('Y-m-d H:i:s');
    if ($endDate && $currentDate > $endDate) {
        // Update status to "not active" in the database
        $updateSql = "UPDATE volunteer_application_form SET status = 'not active' WHERE email = '$username'";
        if ($conn->query($updateSql) === TRUE) {
            // Update successful
            echo "Membership has expired. Status updated to 'not active'.";
        } else {
            // Update failed
            echo "Error updating membership status: " . $conn->error;
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <!-- Include any CSS or JavaScript libraries here -->
</head>
<body>

<h2>Membership Status</h2>
<p><strong>Membership Type:</strong> <?php echo $membershipType; ?></p>
<p><strong>Payment ID:</strong> <?php echo $paymentId; ?></p>
<p><strong>Payment Timestamp:</strong> <?php echo $timestamp; ?></p>
<p><strong>Membership Start Date:</strong> <?php echo $startDate; ?></p>
<p><strong>Membership Expiry Date:</strong> <?php echo $endDate; ?></p> <!-- Added end date -->
<button><a href="testing/payment.php">click here to update member ship</a></button>

<h2>Membership Expiry Countdown</h2>
<p id="countdown"></p>

<script>
    // Set the expiry date for the countdown timer
    var expiryDate = new Date("<?php echo $endDate; ?>").getTime();

    // Update the countdown every second
    var x = setInterval(function() {
        // Get the current date and time
        var now = new Date().getTime();
        
        // Calculate the remaining time
        var distance = expiryDate - now;
        
        // Calculate days, hours, minutes, and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Display the countdown
        document.getElementById("countdown").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
        
        // If the countdown is over, display expired message
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("countdown").innerHTML = "Membership Expired";
        }
    }, 1000);
</script>

</body>
</html>
