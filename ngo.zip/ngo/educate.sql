-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2024 at 08:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `educate`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `content`) VALUES
(1, '<p>Welcome to the NGO. This site aims to be a &#39;one-stop shop&#39; for NGO &nbsp;in humanitarian contexts. Through this site, the International Council of Voluntary Agencies (ICVA) aims to help improve humanitarian preparedness and response by increasing the effectiveness of NGO in humanitarian contexts and their links with other humanitarian coordination mechanisms.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `addmember`
--

CREATE TABLE `addmember` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `work` longtext NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `addmember`
--

INSERT INTO `addmember` (`id`, `name`, `number`, `work`, `img`) VALUES
(2, 'David kanuel', '9928686241', ' Hii hoW r u', 'team-memb1.jpg'),
(4, 'sunil', '0982 866 1887', ' Hi Guys!', 'team-memb2.jpg'),
(5, 'suni1', '0982 866 1887', ' Hi How r u', 'team-memb3.jpg'),
(9, 'Jon', '0982 866 1887', ' Hii I M Designer', 'gmp.png'),
(10, 'Bhargav', '7075739174', ' developer', 'creditcarddb (2).sql');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `post`, `image`, `content`, `date`) VALUES
(3, 'Personal Hygiene And Its Quintessential Roles To Health Enhancement', ' Admin', 'image_02.jpg', '<p>One of the effective ways that can protect you from the prevailing diseases and problems is personal hygiene. It basically refers to the set of practices perceived by a community to be associated with the preservation of health and healthy living.</p>\r\n', 'Thu 13th May 2021'),
(4, 'Role Of Education In Society', ' Admin', 'image_01.jpg', '<p>Education is the social institution through which social provides its members with important knowledge such as culture norm values, job skills and basic facts. It plays a fundamental role in the construction of a good society.</p>\r\n', 'Sat 15th May 2021'),
(5, 'Role Of Women Empowerment And Gender Equ', ' Admin', 'image_06.jpg', '<p>Women empowerment is a serious issue and needs a holistic approach so that rather than focusing on one problem we focus on wide range of issues associated with the same.</p>\r\n', 'Sat 15th May 2021');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `cdate` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `name`, `email`, `mobile`, `msg`, `cdate`) VALUES
(6, 'manvendar', 'manvendra@gmail.com', '9649990607', 'acha hai', '2021-04-28'),
(3, 'No', 'sunilkumar97.sk68@gmail.com', '', 'h', '2021-04-26'),
(7, 'Ajay', 'ajay@gmail.com', '9928686242', 'hii how r u', '2021-04-28'),
(8, 'Atiq', 'admin@gmail.com', '3434545656', 'hii', '2021-04-29'),
(9, 'Bhagyashree', 'info@startsolution.in', '9521234291', 'hoi', '2021-04-29'),
(10, 'Demo NAme', 'otpphp5@gmail.com', '992923233', 'hii', '2021-10-29'),
(11, 'bhargav yaswanth', 'bhargavyaswanth@gmail.com', '07075739174', 'test', '2024-03-29');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `img`) VALUES
(8, 'image_06.jpg'),
(7, 'image_02.jpg'),
(9, 'image_07.jpg'),
(10, 'image_08.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `insideblog`
--

CREATE TABLE `insideblog` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `insideblog`
--

INSERT INTO `insideblog` (`id`, `content`) VALUES
(4, '<p>jbj</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `membership_title` varchar(100) NOT NULL,
  `start_date` datetime NOT NULL,
  `expiry_date` datetime NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Inactive',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nextblog`
--

CREATE TABLE `nextblog` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `pragraph` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nextblog`
--

INSERT INTO `nextblog` (`user_id`, `id`, `pragraph`) VALUES
(1, 3, '<p>hii</p>\r\n'),
(2, 5, '<p>Women empowerment is a serious issue and needs a holistic approach so that rather than focusing on one problem we focus on wide range of issues associated with the sameWomen empowerment is a serious issue and needs a holistic approach so that rather than focusing on one problem we focus on wide range of issues associated with the sameWomen empowerment is a serious issue and needs a holistic approach so that rather than focusing on one problem we focus on wide range of issues associated with the same</p>\r\n'),
(3, 4, '<p>Education is the social institution through which social provides its members with important knowledge such as culture norm values, job skills and basic facts. It plays a fundamental role in the construction of a good societyEducation is the social institution through which social provides its members with important knowledge such as culture norm values, job skills and basic facts. It plays a fundamental role in the construction of a good societyEducation is the social institution through which social provides its members with important knowledge such as culture norm values, job skills and basic facts. It plays a fundamental role in the construction of a good society</p>\r\n'),
(4, 3, '<p>One of the effective ways that can protect you from the prevailing diseases and problems is personal hygiene. It basically refers to the set of practices perceived by a community to be associated with the preservation of health and healthy living.One of the effective ways that can protect you from the prevailing diseases and problems is personal hygiene. It basically refers to the set of practices perceived by a community to be associated with the preservation of health and healthy living.One of the effective ways that can protect you from the prevailing diseases and problems is personal hygiene. It basically refers to the set of practices perceived by a community to be associated with the preservation of health and healthy living.</p>\r\n'),
(5, 3, '<p>sunil</p>\r\n'),
(6, 4, '<p>suil1</p>\r\n'),
(7, 5, '<p>sunil3</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `ourwork`
--

CREATE TABLE `ourwork` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ourwork`
--

INSERT INTO `ourwork` (`id`, `content`) VALUES
(1, '<h2><big>Health</big></h2>\r\n\r\n<p>Many years have passed after we gained freedom, and India is yet to offer basic healthcare services to its population. Health is still the issue in India and thus we have come up to overcome this problem at the earliest. NGO is honored as the leading NGO in Delhi that offer medical help to the needy people.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>Education</h2>\r\n\r\n<p>Education is the right of every kid and keeping this fact in mind, we are striving hard for the betterment of the unprivileged by arranging education opportunities for them. Education is the sole thing that can take our country to the unmatched heights and thus our NGO aims at educating needy children who cannot study due to lack of opportunities and resources.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2>Livelihood</h2>\r\n\r\n<p>Unemployment is the major problem of India, owing to lack of knowledge and guidance. Almost one-third of Indian population is youth who is striving hard to get employment these days. NGO is set up to offer employment opportunities to the underprivileged so that they can earn livelihood and live a better life, without relying on others.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h1>&nbsp;</h1>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `membership_type` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `membership_type`, `amount`, `payment_id`, `timestamp`) VALUES
(1, '', 0, '', '2024-04-04 05:13:25'),
(2, '', 0, '', '2024-04-04 05:14:10'),
(3, '', 0, '', '2024-04-04 05:15:07'),
(4, '', 0, '', '2024-04-04 05:17:24'),
(5, '', 0, '', '2024-04-04 05:19:45'),
(6, 'Premium', 3000, 'pay_NuUBxhFFsjcpTK', '2024-04-04 03:22:52');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `exam` varchar(200) NOT NULL,
  `marks` varchar(100) NOT NULL,
  `photo` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `name`, `exam`, `marks`, `photo`, `status`) VALUES
(1, ' ', ' ', ' ', '1.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `social1` varchar(255) NOT NULL,
  `social2` varchar(255) NOT NULL,
  `social3` varchar(255) NOT NULL,
  `social4` varchar(255) NOT NULL,
  `sociallink1` longtext NOT NULL,
  `sociallink2` longtext NOT NULL,
  `sociallink3` longtext NOT NULL,
  `sociallink4` longtext NOT NULL,
  `gmail` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `address` longtext NOT NULL,
  `website` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `social1`, `social2`, `social3`, `social4`, `sociallink1`, `sociallink2`, `sociallink3`, `sociallink4`, `gmail`, `number`, `address`, `website`, `companyname`, `logo`) VALUES
(1, '        fab fa-facebook-square', 'fab fa-instagram', 'fab fa-twitter', 'fab fa-linkedin', 'https://facebook.com/', 'https://instagram.com/', 'https://twiter.com/', 'https://instagram.com/', 'active24x7charitabletrust@gmail.com', '8522888090', 'Deep ji ki Badi', '24/7ChartiableTrust.org', '24/7 Chartiable Trust', 'PHOTO-2023-08-05-08-09-40.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(10) UNSIGNED NOT NULL,
  `img` varchar(45) DEFAULT NULL,
  `sl` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `img`, `sl`) VALUES
(31, '31.jpg', 4),
(32, '32.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `super`
--

CREATE TABLE `super` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `wing` varchar(255) NOT NULL,
  `donate` int(11) NOT NULL,
  `cdate` varchar(15) NOT NULL,
  `status` tinyint(4) DEFAULT 0,
  `pay_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `super`
--

INSERT INTO `super` (`id`, `name`, `mobile`, `email`, `wing`, `donate`, `cdate`, `status`, `pay_id`) VALUES
(165, 'Sunil', '9928686241', 'otp@gmail.com', '', 0, '2021-02-25', 0, NULL),
(166, 'WappBlaster', '7230007458', 'sunilkumar97.sk68@gmail.com', '', 12, '2021-04-22', 0, NULL),
(167, 'Ajay', '+919079646229', 'sunilkumar97.sk68@gmail.com', '', 100, '2021-04-22', 1, NULL),
(168, 'No', '09928686241', 'sunilkumar97.sk68@gmail.com', '', 11, '2021-04-22', 1, NULL),
(169, 'WappBlaster devi', '7230007458', 'sunilkumar97.sk68@gmail.com', '', 101, '2021-04-22', 0, NULL),
(170, 'babyu', '09928686241', 'sunilkumar97.sk68@gmail.com', '', 11, '2021-04-22', 0, NULL),
(171, 'WappBlaster devi', '7230007458', 'sunilkumar97.sk68@gmail.com', '', 101, '2021-04-22', 0, NULL),
(172, 'babu1', '999090909090', 'babu@gmail.com', '', 1033, '2021-04-22', 0, NULL),
(173, 'babu6', '434546', 'bfg@gmail.com', '', 3424, '2021-04-22', 0, NULL),
(174, 'Sk2', '99922727727', 'easystep25@gmail.com', '', 100, '2021-04-22', 0, NULL),
(175, 'monty sir', '909898w94', 'xcxv@gmail.com', '', 100, '2021-04-23', 0, NULL),
(176, 'Punam', '06350015053', 'sunilkumar97.sk68@gmail.com', '', 100, '2021-04-23', 0, NULL),
(177, '', '', '', '', 0, '2021-04-24', 0, NULL),
(178, '', '', '', '', 0, '2021-04-24', 0, NULL),
(179, 'No1', '09928686241', 'sunilkumar97.sk68@gmail.com', '', 100, '2021-04-24', 0, NULL),
(180, 'hii', '99286862433', 'df@gmail.com', '', 105, '2021-04-24', 0, NULL),
(181, 'sanket NA PARDESHI', '9881972211', 'sanketp19999@gmail.com', '', 1000, '2021-04-26', 0, NULL),
(182, 'manv', '9649990607', 'manvendra@gmail.com', '', 25000, '2021-04-28', 0, NULL),
(183, 'Harish', '1234567890', 'hari123@gmail.com', '', 2, '2021-04-28', 0, NULL),
(184, 'Manu', '8529713943', 'Abc1234@gmail.com', '', 50, '2021-04-28', 0, NULL),
(185, 'Atiq', '3434545656', 'atik7373@gmail.com', '', 1000, '2021-04-29', 0, NULL),
(186, 'Bhagyashree', '9521234291', 'info@startsolution.in', '', 2000, '2021-04-29', 0, NULL),
(187, 'gvbn', '7501565421', 'info@mgnika.com', '', 500000, '2021-04-30', 0, NULL),
(188, 'sunil kumar', '09079646229', 'sunilkumar97.sk68@gmail.com', '', 12, '2021-04-30', 0, NULL),
(189, 'test', '8888888888', 'charity@naaridunia.in', '', 5000, '2021-06-25', 0, NULL),
(190, 'Ajay Dabas', '08571875658', 'ajayaddabas@gmail.com', '', 5000, '2021-10-06', 0, NULL),
(191, 'gkkk', '09928686241', 'sunilkumar97.sk68@gmail.com', '', 100, '2021-10-06', 0, NULL),
(192, 'gkkk', '09928686241', 'es@gmail.com', '', 100, '2021-10-06', 0, NULL),
(193, 'gkkk', '9893929922', 'es@gmail.com', '', 100, '2021-10-06', 0, NULL),
(194, 'demo111', '9909999999', 'sky@gmail.com', '', 11, '2021-10-07', 0, NULL),
(195, 'Heeralal', '90008990900', 'ssskkk@gmail.com', '', 110, '2021-10-29', 0, NULL),
(196, 'Madhu', '7810052480', 'test@gmail.com', '', 300, '2021-11-02', 0, NULL),
(197, 'Maa Foundation ', '98613 28384', 'mahapatraamit447@gmail.com', '', 100, '2021-11-02', 0, NULL),
(198, 'Ee', '052517922821', 'yijidif923@hubopss.com', '', 55, '2021-11-08', 0, NULL),
(199, 'T', '8', 'a@a.uk', '', 11, '2021-11-08', 0, NULL),
(200, 'Dhruv Tomar', '9084533651', 'atalgausewatrust@gmail.com', '', 5000, '2021-11-09', 0, NULL),
(201, 'Dhruv Tomar', '9084533651', 'atalgausewatrust@gmail.com', '', 5000, '2021-11-09', 0, NULL),
(202, 'Nirmal', 'Fg', 'gg@gmail.com', '', 0, '2021-11-14', 0, NULL),
(203, 'sunil kumar', '09079646229', 'sunilkumar97.sk68@gmail.com', '', 99, '2021-11-14', 0, NULL),
(204, 'Kalpesh Vasava', '09913950465', 'kalpeshvasava5080@gmail.com', '', 100, '2021-11-14', 0, NULL),
(205, 'Kalpesh Vasava', '09913950465', 'kalpeshvasava5080@gmail.com', '', 300, '2021-11-14', 0, NULL),
(206, 'Kalpesh Vasava', '09913950465', 'kalpeshvasava5080@gmail.com', '', 300, '2021-11-15', 0, NULL),
(207, 'KALPESHBHAI', '9913950465', 'kalpeshvasava5080@gmail.com', '', 5, '2021-11-20', 0, NULL),
(208, 'He', '818', 'ika@hlh.com', '', 1, '2021-11-22', 0, NULL),
(209, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-29', 1, NULL),
(210, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-30', 1, NULL),
(211, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-30', 1, NULL),
(212, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-31', 1, NULL),
(213, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-31', 1, NULL),
(214, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', '', 15, '2024-03-31', 1, NULL),
(215, 'bhargav yaswanth', '07075739174', '', '', 15, '2024-03-31', 0, NULL),
(216, 'bhargav yaswanth', '07075739174', '', '', 10, '2024-03-31', 0, NULL),
(217, 'bhargav yaswanth', '7075739174', '', '', 10, '2024-03-31', 0, NULL),
(218, 'bhargav yaswanth', '7075739174', '', '', 10, '2024-03-31', 0, NULL),
(219, 'bhargav yaswanth', '07075739174', '', '', 15, '2024-03-31', 0, NULL),
(220, 'bhargav yaswanth', '7075739174', '', '', 15, '2024-03-31', 0, NULL),
(221, 'bhargav yaswanth chindada', '7075739174', 'bhargavyaswanth@gmail.com', '', 23, '2024-03-31', 0, NULL),
(222, 'bhargav yaswanth chindada', '7075739174', '20NU1A0517@nsrit.edu.in', '', 23, '2024-03-31', 0, NULL),
(223, 'bhargav yaswanth chindada', '7075739143', '20NU1A0517@nsrit.edu.in', '', 23, '2024-03-31', 0, NULL),
(224, 'bhargav yaswanth', '07075739111', 'bhargavyaswanth@gmail.com', 'Employment', 10, '2024-03-31', 1, NULL),
(225, 'bhargav yaswanth', '7075739121', 'bhargavyaswanth@gmail.com', 'Skill Development and Employmen', 10, '2024-03-31', 1, NULL),
(226, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', 'Blood Donaion', 15, '2024-03-31', 0, NULL),
(227, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', 'Active inspiring &event-organaising ', 15, '2024-03-31', 0, NULL),
(228, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', 'Food Donation', 15, '2024-03-31', 0, NULL),
(229, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', 'Employment', 10, '2024-03-31', 0, NULL),
(230, 'bhargav yaswanth', '07075739171', 'bhargavyaswanth@gmail.com', 'Food Donation', 10, '2024-03-31', 1, NULL),
(231, 'bhargav yaswanth', '7075739', 'bhargavyaswanth@gmail.com', 'Employment', 10, '2024-03-31', 0, NULL),
(232, 'bhargav yaswanth', '07075739174', 'bhargavyaswanth@gmail.com', 'Food Donation', 10, '2024-04-03', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usr`
--

CREATE TABLE `tbl_usr` (
  `id` int(11) NOT NULL,
  `un` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_usr`
--

INSERT INTO `tbl_usr` (`id`, `un`, `pw`) VALUES
(1, 'admin', 'admin@#123');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `phonenumber`, `address`, `city`, `state`, `zip`) VALUES
(1, 'bhargavyaswanth@gmail.com', '$2y$10$qhcGc5a2/XEulPm96BTIt.1OsNrbI672m17nGBh/8g7zoisoiL9Wm', '07075739174', 'S2 R And B Quarter Seethammadhara', 'vizag', 'AP', '530013');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_application_form`
--

CREATE TABLE `volunteer_application_form` (
  `id` int(11) NOT NULL,
  `title` varchar(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `blood_group` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_relationship` varchar(100) DEFAULT NULL,
  `emergency_contact_phone_number` varchar(15) DEFAULT NULL,
  `emergency_contact_email` varchar(100) DEFAULT NULL,
  `previous_volunteer_experience` varchar(3) DEFAULT NULL,
  `experience_details` text DEFAULT NULL,
  `volunteer_motivation` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `availability` text DEFAULT NULL,
  `declaration` varchar(3) DEFAULT NULL,
  `membership_start_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `membership_expiry_date` timestamp GENERATED ALWAYS AS (`membership_start_date` + interval 1 month) STORED,
  `membership_title` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'not active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteer_application_form`
--

INSERT INTO `volunteer_application_form` (`id`, `title`, `name`, `address`, `mobile_number`, `blood_group`, `date_of_birth`, `email`, `emergency_contact_name`, `emergency_contact_relationship`, `emergency_contact_phone_number`, `emergency_contact_email`, `previous_volunteer_experience`, `experience_details`, `volunteer_motivation`, `skills`, `availability`, `declaration`, `membership_start_date`, `membership_title`, `status`) VALUES
(1, 'mr', 'bhargav yaswanth', 'S2 R And B Quarter Seethammadhara', '07075739174', 'g', '2024-04-04', 'bhargavyaswanth@gmail.com', 'bhargav yaswanth', 'afaef', '07075739174', 'bhargavyaswanth@gmail.com', 'yes', 'hgcut', 'ikhviyhgiy', 'iuyfiuyyiu', 'weekday_morning, weekday_afternoon', 'Yes', '2024-04-04 09:39:32', 'Basic', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `whatwe`
--

CREATE TABLE `whatwe` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `whatwe`
--

INSERT INTO `whatwe` (`id`, `title`, `image`, `content`) VALUES
(8, '#Mylifeat15', 'image_06.jpg', '<p>#MyLifeAt15 celebrates the dreams and ambitions we hold at the age of 15 in support of every girl having the opportunity to achieve hers, without child marriage holding her back.</p>\r\n'),
(9, 'Desert life and Crafts', 'image_01.jpg', '<p>In its initial stage of working on health, with an agenda of complementing the dairy&rsquo;s activities, Ngo Trust team did not have any idea that it would soon need to shift its focus from health care to income generation.</p>\r\n'),
(10, '#Mylifeat15', 'image_03.jpg', '<p>#MyLifeAt15 celebrates the dreams and ambitions we hold at the age of 15 in support of every girl having the opportunity to achieve hers, without child marriage holding her back.</p>\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addmember`
--
ALTER TABLE `addmember`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `nextblog`
--
ALTER TABLE `nextblog`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `ourwork`
--
ALTER TABLE `ourwork`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `super`
--
ALTER TABLE `super`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_usr`
--
ALTER TABLE `tbl_usr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volunteer_application_form`
--
ALTER TABLE `volunteer_application_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `whatwe`
--
ALTER TABLE `whatwe`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `addmember`
--
ALTER TABLE `addmember`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ourwork`
--
ALTER TABLE `ourwork`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `super`
--
ALTER TABLE `super`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `tbl_usr`
--
ALTER TABLE `tbl_usr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `volunteer_application_form`
--
ALTER TABLE `volunteer_application_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `whatwe`
--
ALTER TABLE `whatwe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `memberships`
--
ALTER TABLE `memberships`
  ADD CONSTRAINT `memberships_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
