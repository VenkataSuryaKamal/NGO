<!doctype html>

<?php
date_default_timezone_set('Asia/Calcutta');
ob_start(); 
session_start();
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache");
header("Pragma: no-cache");
if(isset($_SESSION["u_id"])){
    include 'admin/inc/db.php';
    $api_key="rzp_test_DT1FmIE6tqtiAQ";
    //$api_key="rzp_test_B0tLu8e8avMivY";
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Donate</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon">
   <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<style>


body {
    background:#333;
}
#login {
	-webkit-perspective: 1000px;
	-moz-perspective: 1000px;
	perspective: 1000px;
	margin-top:50px;
	margin-left:30%;
}
.login {
	font-family: 'Josefin Sans', sans-serif;
	-webkit-transition: .3s;
	-moz-transition: .3s;
	transition: .3s;
	-webkit-transform: rotateY(40deg);
	-moz-transform: rotateY(40deg);
	transform: rotateY(40deg);
}
.login:hover {
	-webkit-transform: rotate(0);
	-moz-transform: rotate(0);
	transform: rotate(0);
}
.login article {
	
}
.login .form-group {
	margin-bottom:17px;
}
.login .form-control,
.login .btn {
	border-radius:0;
}
.login .btn {
	text-transform:uppercase;
	letter-spacing:3px;
}
.input-group-addon {
	border-radius:0;
	color:#fff;
	background:#f3aa0c;
	border:#f3aa0c;
}
.forgot {
	font-size:16px;
}
.forgot a {
	color:#333;
}
.forgot a:hover {
	color:#5cb85c;
}

#inner-wrapper, #contact-us .contact-form, #contact-us .our-address {
    color: #1d1d1d;
    font-size: 19px;
    line-height: 1.7em;
    font-weight: 300;
    padding: 50px;
    background: #fff;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
    margin-bottom: 100px;
}
.input-group-addon {
    border-radius: 0;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
    color: #fff;
    background: #f3aa0c;
    border: #f3aa0c;
        border-right-color: rgb(243, 170, 12);
        border-right-style: none;
        border-right-width: medium;
padding:5px;
}
 
</style>
</head>

<body>

  <?php
require_once('header.php');
?>
  <!--  ************************* Page Title Starts Here ************************** -->
        
    <div class="page-nav no-margin row">
        <div class="container">
            <div class="row">
                <h2>Donate Now</h2>
                <ul>
                    <li> <a href="#"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="logout.php"><i class="fas fa-angle-double-right"></i> Log out</a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <?php
$sql = $dbh->prepare("select * from super where mobile = '$_SESSION[u_id]'");
    $sql->execute();
    $rs = $sql->fetch();
?>
   
 <!--  ************************* Gallery Starts Here ************************** --><hr>
         <div class="container">
							<table class="table table-bordered">
	<tbody>
		<tr>
			<th>Name</th>
			<td><?php echo $rs['name'];?></td>
		</tr>
		<tr>
			<th>Mobile No</th>
			<td><?php echo $rs['mobile'];?></td>
		</tr>
		
		
			<tr>
			<th>Email</th>
			<td><?php echo $rs['email'];?></td>
		</tr>
    
    <tr>
			<th>Wing</th>
			<td><?php echo $rs['wing'];?></td>
		</tr>
	 
	 
		<tr>
			<th>Donation</th>
			<td><?php echo $rs['donate'];?></td>
		</tr>

		<tr>
			<th>Payment Status</th>
			<td>
				<?php
				if ($rs['status']==0) { echo "<font color='red'>Payment is Pending</font>";}
				else{echo "<font color='green'>Payment Done</font>";
				    echo ' <input type="button" value="Print Ngo Certificate" class="btn btn-primary btn-sm" onclick="printDiv()">';
				}
				?>				
			</td>
		</tr>
	</tbody>
</table>
</div>

<div id="GFG" style="visibility: hidden;"> 
        <h3 align="center">NGO </h3> 
        <p align="justify">Dear <b><?php echo $rs['name'];?></b>, Congratulation  You have successfully registered for NGO </p>
          <table border="0">
          	<tbody>
		<tr>
			<th align="left">Mobile No</th>
			<td><?php echo $rs['mobile'];?></td>
		</tr>
		<!--<tr>
			<th align="left">Exam Mode</th>
			<td><?php echo $rs['mode'];?></td>
		</tr>-->
		<tr>
			<th align="left">Name</th>
			<td><?php echo $rs['name'];?></td>
		</tr>

    <tr>
			<th align="left">Amount</th>
			<td><?php echo $rs['donate'];?></td>
		</tr>
    <tr>
			<th align="left">Wing</th>
			<td><?php echo $rs['wing'];?></td>
		</tr>
		<tr>
			<th align="left">Payment Status</th>
			<td>
				<?php
				if ($rs['status']==0) { echo "Payment is Pending";}
				else{echo "Payment Done";
			}
				?>  				
			</td>
		</tr>
		<tr>
			<td colspan="2"><br></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><b>Note:- Visit our website regularly You Can Donate Again.</b></td>
		</tr>          
          </table>
    </div> 
    
    <style>
        button, input, optgroup, select, textarea {
    margin-left: 650px;
    
    margin-bottom:60px;
    font: inherit;
    color: red;
}
    </style>
    
<?php
if ($rs['status']==0) {?>
		<form action="donatesuccess.php" method="POST"  style="margin-top:-256px">
		<script    src="https://checkout.razorpay.com/v1/checkout.js"
		  data-key="<?php echo $api_key; ?>"
		  data-amount="100"
		  data-currency="INR"
		  data-id="<?php echo 'EDU'.rand(10,100).'S30' ?>"
		  data-buttontext="Pay Now"
		  data-name="NGo "
		  data-description="You Can Donate "
		  data-image="assets/images/logo.png"
"
		  data-prefill.contact="<?php echo $rs['mobile'];?>"
		  data-prefill.name="<?php echo $rs['name'];?>"
		  data-prefill.email="<?php echo $rs['email'];?>"
      data-prefill.email="<?php echo $rs[''];?>"

		  data-theme.color="#0072bb">
		</script>
		<input type="hidden" custom="Hidden Element" name="hidden" style="margin-left:-466px"></form>
	<?php } ?>
	</div></div></div>


<div class="container">
    <div class="row">
    <div class="col-md-1">
        
        
        
    </div>
    
     <div class="col-md-4">
        
        </div>	<div role="tabpanel" class="tab-pane" id="crash"><div class="kf_courses_detail_des"><div class="course_heading"><h3>Download Certificate Of Ngo</h3></div><p> Coming Soon...!</p></div></div></div></div></div></div></div></div> </section></div>
        
    </div>
    
    
     <div class="col-md-4">
        
        
        
    </div>
    
    </div>
    
    




					 
                 
  <!--  ************************* Footer Starts Here ************************** -->
          
      <?php
require_once('footer.php');
?>
  
  
  <!-- Trigger the modal with a button -->
  <style>
      
      .modal .uploadeimg{
          
         width:100px;
         margin-left:178px;
      }
      
      
       @media screen and (max-width: 900px){
.modal .uploadeimg{
	
	     
    margin-left: 100px;
	
}
}
  </style>
<?php
error_reporting(0);

 
     include 'admin/inc/db1.php';
    
    
    if(isset($_POST['save']))
    
    {
        $name=$_POST['name'];
                $number=$_POST['number'];
                  $work=$_POST['work'];
        $img=$_FILES["img1"]["name"];
        move_uploaded_file($_FILES["img1"]["tmp_name"],"slide/".$_FILES["img1"]["name"]);
        
        
         $sql="INSERT INTO addmember(name,number,work,img) VALUES('$name','$number','$work','$img')";
    $res=mysqli_query($con,$sql);
    if($res)
    {
       echo '<script>alert("Welcome Our Ngo.");window.location.href="index.php";</script>';
        
        
    }
    else
    {
         echo '<script>alert("Plz try Again.");window.location.href="index.php";</script>';
    }
    }
    

?>
  <!-- Modal -->
  <div class="modal" tabindex="-1" role="dialog" id="myModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Member</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              <form  method="post" enctype="multipart/form-data">
             <input name="name" class="form-control" required  placeholder="Enter Your Name"/>
      
             
               <input name="number" class="form-control"  required  placeholder="Enter Your Number"/>
           
               <h5>What Your Work</h5>
               <textarea class="form-control"  required  name="work"> </textarea>
               
               <div class="uploadeimg">
                   
               <img src="blank_avatar.jpg
" >

<input type="file" name="img1" style="padding-top:10px;padding-bottom:10px;margin-left:-50px" required>
</div>


<button name="save" type="submit" class="btn btn-success btn-block">Submit</button>
</form>
                  
           </div>
     
    </div>
  </div>
</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>
<script src="assets/plugins/slider/js/owl.carousel.min.js"></script>
<script src="assets/js/script.js"></script>

</html>

<script> 
        function printDiv() { 
            var divContents = document.getElementById("GFG").innerHTML; 
            var a = window.open('', '', 'height=500, width=500'); 
            a.document.write('<html>'); 
            a.document.write('<body><div height="100px;" align="center"><h1>Demo</div>'); 
            a.document.write(divContents); 
            a.document.write('</body></html>'); 
            a.document.close(); 
            a.print(); 
        } 
    </script> 

<?php }
else{
	header("location: donate.php");
}?>
