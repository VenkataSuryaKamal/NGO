<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

require_once('database.php'); // Include your database connection file

// Check if the user exists in the database
$username = $_SESSION['username'];
$sql = "SELECT * FROM volunteer_application_form WHERE email = '$username'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // User not found in the table, display the "Become a Member" button
    $showMembershipButton = true;
} else {
    // User found in the table, do not display the "Become a Member" button
    $showMembershipButton = false;
}

// Example array of membership types with prices
$membershipTypes = array(
    array("title" => "Basic Membership", "price" => "50"),
    array("title" => "Standard Membership", "price" => "100"),
    array("title" => "Premium Membership", "price" => "150")
);
?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>

<body>
<?php require_once('afterlogin.php'); ?>

<div class="container mt-4">
    <h3><?php echo "Welcome " . $_SESSION['username'] ?>! You can now use this website</h3>
    <?php if ($showMembershipButton): ?>
        <button><a href="membership.php">Become a Member</a></button>
        <hr>
    <?php endif; ?>
</div>

    <div class="container">
        <div class="row row-cols-4">
            <?php foreach ($membershipTypes as $membership): ?>
                <div class="col">
                    <div class="card">
                        <img src="https://via.placeholder.com/300" class="card-img-top" alt="Placeholder Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $membership['title']; ?></h5>
                            <p class="card-text">Price: <?php echo $membership['price']; ?></p>
                            <button class="btn btn-primary" onclick="payWithRazorpay('<?php echo $membership['title']; ?>', '<?php echo $membership['price']; ?>')">Buy Now</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Add this script tag in your HTML -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>

    <script>
        function payWithRazorpay(itemName, amount) {
            var options = {
                key: 'rzp_test_DT1FmIE6tqtiAQ', // Replace with your Razorpay Key ID
                amount: amount * 100, // Amount is in currency subunits. 100 refers to 100 paise or 1 rupee
                currency: 'INR', // You can specify any ISO 4217 currency code here. Eg: USD for US Dollars, INR for Indian Rupees
                name: '24/7 Char',
                description: itemName,
                image: 'https://via.placeholder.com/150', // Logo image URL
                handler: function(response) {
                    // This function will be called after a successful payment
                    alert('Payment successful! Payment ID: ' + response.razorpay_payment_id);
                    // You can add additional logic here such as updating the database, redirecting user, etc.
                },
                prefill: {
                    name: 'Customer Name',
                    email: 'customer@example.com'
                }
            };
            var rzp = new Razorpay(options);
            rzp.open();
        }
    </script>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
