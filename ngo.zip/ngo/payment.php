<?php
session_start();
date_default_timezone_set('Asia/Calcutta');

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Membership Plans</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
            border-radius: 5px;
        }

        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        }

        .container {
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Select a Membership Plan</h2>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Basic Membership</h5>
                    <p class="card-text">Price: $10</p>
                    <button class="btn btn-primary" onclick="initiatePayment('Basic', 1000)">Buy Now</button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Standard Membership</h5>
                    <p class="card-text">Price: $20</p>
                    <button class="btn btn-primary" onclick="initiatePayment('Standard', 2000)">Buy Now</button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Premium Membership</h5>
                    <p class="card-text">Price: $30</p>
                    <button class="btn btn-primary" onclick="initiatePayment('Premium', 3000)">Buy Now</button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Ultimate Membership</h5>
                    <p class="card-text">Price: $50</p>
                    <button class="btn btn-primary" onclick="initiatePayment('Ultimate', 5000)">Buy Now</button>
                </div>
            </div>
        </div>
    </div>

    <div id="payment-details" style="display: none;">
        <h2>Payment Details</h2>
        <p id="membership-type"></p>
        <p id="amount"></p>
        <p id="payment-id"></p>
        <p id="timestamp"></p>
    </div>
</div>
   <script>
    function getCurrentIndianTime() {
        var now = new Date();
        var options = { timeZone: 'Asia/Kolkata', hour12: false };
        return now.toLocaleString('en-US', options).replace(',', ''); // Remove comma from the time format
    }

    function initiatePayment(membershipType, amount) {
        var options = {
            "key": "rzp_test_DT1FmIE6tqtiAQ",
            "amount": amount, // Amount in paise (1 Rupee = 100 paise)
            "name": "Your Company Name",
            "description": "Membership Payment",
            "handler": function (response){
                var paymentId = response.razorpay_payment_id;
                var timestamp = getCurrentIndianTime(); // Get current Indian time
                var formData = new FormData();
                formData.append('membershipType', membershipType);
                formData.append('amount', amount);
                formData.append('paymentId', paymentId);
                formData.append('timestamp', timestamp);

                fetch('process_payment.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    console.log(data);
                    document.getElementById('membership-type').innerText = "Membership Type: " + membershipType;
                    document.getElementById('amount').innerText = "Amount: $" + (amount / 100);
                    document.getElementById('payment-id').innerText = "Payment ID: " + paymentId;
                    document.getElementById('timestamp').innerText = "Timestamp: " + timestamp;
                    document.getElementById('payment-details').style.display = 'block';
                    
                    setTimeout(function() {
                        window.location.href = "homepage.php"; // Change to your home page URL
                    }, 3000);
                })
                .catch(error => console.error('Error:', error));
            },
            "prefill": {
                "name": "John Doe",
                "email": "john.doe@example.com",
            },
            "theme": {
                "color": "#528FF0"
            }
        };
        var rzp = new Razorpay(options);
        rzp.open();
    }
</script>

</body>
</html>
