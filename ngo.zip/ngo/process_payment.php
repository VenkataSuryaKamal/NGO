<?php
session_start();

// Fetch POST data
date_default_timezone_set('Asia/Calcutta');
$membershipType = isset($_POST['membershipType']) ? $_POST['membershipType'] : '';
$amount = isset($_POST['amount']) ? $_POST['amount'] : '';
$paymentId = isset($_POST['paymentId']) ? $_POST['paymentId'] : '';
$timestamp = isset($_POST['timestamp']) ? $_POST['timestamp'] : '';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // User is not logged in, redirect to login page
    header("location: login.php");
    exit;
}

// Retrieve email from session
$email = $_SESSION['username'];


// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "educate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define status based on payment success
$status = ($paymentId != '') ? 'active' : 'pending';

// Update membership details in the volunteer_application_form table based on email
$sql = "UPDATE volunteer_application_form SET membership_title='$membershipType', membership_start_date='$timestamp', status='$status' WHERE email='$email'";

if ($conn->query($sql) === TRUE) {
    echo "Membership details updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
