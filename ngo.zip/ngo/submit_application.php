<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "educate";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$title = $_POST['title'];
$name = $_POST['name'];
$address = $_POST['address'];
$mobile_number = $_POST['mobile_number'];
$blood_group = $_POST['blood_group'];
$date_of_birth = $_POST['date_of_birth'];
$email = $_POST['email'];
$emergency_contact_name = $_POST['emergency_contact_name'];
$emergency_contact_relationship = $_POST['emergency_contact_relationship'];
$emergency_contact_phone_number = $_POST['emergency_contact_phone_number'];
$emergency_contact_email = $_POST['emergency_contact_email'];
$previous_volunteer_experience = isset($_POST['previous_volunteer_experience']) ? $_POST['previous_volunteer_experience'] : '';
$experience_details = isset($_POST['experience_details']) ? $_POST['experience_details'] : '';
$volunteer_motivation = $_POST['volunteer_motivation'];
$skills = $_POST['skills'];
$availability = isset($_POST['availability']) ? implode(', ', $_POST['availability']) : '';
$declaration = isset($_POST['declaration']) ? 'Yes' : 'No';

// Prepare and execute SQL query to insert data into the database
$sql = "INSERT INTO volunteer_application_form (title, name, address, mobile_number, blood_group, date_of_birth, email, emergency_contact_name, emergency_contact_relationship, emergency_contact_phone_number, emergency_contact_email, previous_volunteer_experience, experience_details, volunteer_motivation, skills, availability, declaration)
VALUES ('$title', '$name', '$address', '$mobile_number', '$blood_group', '$date_of_birth', '$email', '$emergency_contact_name', '$emergency_contact_relationship', '$emergency_contact_phone_number', '$emergency_contact_email', '$previous_volunteer_experience', '$experience_details', '$volunteer_motivation', '$skills', '$availability', '$declaration')";

if ($conn->query($sql) === TRUE) {
    // Redirect to type.php
    header("Location: payment.php");
    exit(); // Ensure that script stops executing after redirection
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
// Close connection
$conn->close();
?>
