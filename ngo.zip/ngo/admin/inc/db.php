<?php

//$dbh = new PDO('mysql:host=localhost;dbname=u386968316_ngo', 'u386968316_userngo', 'Demodemo####12345@');
$dbh = new PDO('mysql:host=localhost;dbname=educate', 'root', '');
?> 