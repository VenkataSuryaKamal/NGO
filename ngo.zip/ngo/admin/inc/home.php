                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                <p class="card-text">
                                <h5 class="card-title">Total users</h5>

                        <?php
                            // Fetch total number of users from the database
                            $sql = "SELECT COUNT(*) AS total_users FROM users";
                            $stmt = $dbh->query($sql);
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['total_users'];
                        ?>
                    </p>                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                <div class="card-body">
                    <h5 class="card-title">Total Donations</h5>
                    <p class="card-text">
                        <?php
                            // Fetch total sum of donations where status is 1 from the database
                            $sql = "SELECT SUM(donate) AS total_donations FROM super WHERE status = 1";
                            $stmt = $dbh->query($sql);
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['total_donations'] ? '$' . $row['total_donations'] : '$0'; // Displaying in currency format
                        ?>
                    </p>
                </div>                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    

                                <h5 class="card-title">Total Membership users</h5>
                                <p class="card-text">
                        <?php
                            // Fetch total sum of donations where status is 1 from the database
                            $sql = "SELECT COUNT(*) AS count FROM volunteer_application_form";
                            $stmt = $dbh->query($sql);
                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $row['count']; // Displaying in currency format
                        ?>
                    </p>                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">##</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <!-- <div class="row">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area mr-1"></i>
                                        Area Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar mr-1"></i>
                                        Bar Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                        </div>-->
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                New Donation 
                                <button id="btnExport" class="btn btn-danger btn-sm" style="float:right;" onclick="exportToExcel()">EXPORT REPORT</button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                 <th>Email</th>
                                               <th>Phone</th>
                                               
                                             <th>Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                            <?php
                                                $sql="select * from super order by id desc";
                                                $i = 1;
                                                
                                                 foreach ($dbh->query($sql) as $rs)
                                                {
                                                    if ($rs['status']==0) {
                                                    $pay='Not Paid';                                                                                                            
                                                    }
                                                    else{
                                                        $pay='Paid';
                                                    }
                                                ?>
                                            <tr>
                                                
                                                <td><?php echo $rs['name']; ?></td>
                                                 
                                               
                                                <td><?php echo $rs['email']; ?></td>
                                                 <td><?php echo $rs['mobile']; ?></td>
                                              
                                                <td><?php echo $rs['cdate']; ?></td>
                                                
                                                <td><?php echo $pay; ?></td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    function exportToExcel() {
        let table = document.getElementById("dataTable");
        let html = table.outerHTML;
        let url = 'data:application/vnd.ms-excel,' + escape(html); // Data URI
        let link = document.createElement("a");
        link.href = url;
        link.download = "donations.xls";
        link.click();
    }
</script>

                </main>
                
                
                