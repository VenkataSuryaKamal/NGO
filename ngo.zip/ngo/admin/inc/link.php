<div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <!--<div class="sb-sidenav-menu-heading">Core</div>-->
                            <a class="nav-link" href="page.php?pg=home">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            
                            
                            
                         
                         
                         
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            
                              
                            
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#slider" aria-expanded="false" aria-controls="slider">
                                
                                
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                
                                Slide
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                
                            </a>
                            <div class="collapse" id="slider" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="page.php?pg=add_slide">New</a>
                                    <a class="nav-link" href="page.php?pg=view_slide">View</a>
                                </nav>
                            </div>
                            <a class="nav-link" href="page.php?pg=memberships">
                                <div class="sb-nav-link-icon"><i class="fa fa-gear fa-spin"></i></div>
                                Memberships
                            </a>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                                
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#about" aria-expanded="false" aria-controls="slider">
                                
                                
                                <div class="sb-nav-link-icon"><i class="fa fa-user"></i></div>
                                
                                About
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                
                            </a>
                            <div class="collapse" id="about" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                
                                <nav class="sb-sidenav-menu-nested nav">
                                   
                                    <a class="nav-link" href="page.php?pg=addabout">Add About</a>
                                </nav>
                            </div>
                            
                            
                            
                             <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#gallery" aria-expanded="false" aria-controls="slider">
                                
                                
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                
                                Gallery
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                
                            </a>
                            <div class="collapse" id="gallery" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="page.php?pg=add_gallery">New</a>
                                    <a class="nav-link" href="page.php?pg=view_gallery">View</a>
                                </nav>
                            </div>
                            
                            
                                <a class="nav-link" href="page.php?pg=ourwork">
                                <div class="sb-nav-link-icon"><i class="fa fa-user"></i></div>
                            Our Work
                            </a>
                            
                            
                            
                             
                             
                                  <a class="nav-link" href="page.php?pg=enquiry">
                                <div class="sb-nav-link-icon"><i class="fa fa-user"></i></div>
                                Enquiry
                            </a>
                            
                            
                            
                                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Whatwedo" aria-expanded="false" aria-controls="slider">
                                
                                
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                
                                 What we do
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                
                            </a>
                            <div class="collapse" id="Whatwedo" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="page.php?pg=Whatwe">New</a>
                                    <a class="nav-link" href="page.php?pg=view_whatdo">View</a>
                                    
                                    
                                </nav>
                            </div>
                            
                            
                            
                            
                            
                            
                                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Blog" aria-expanded="false" aria-controls="slider">
                            
                            
                             <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                
                                 Our Blog 
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                
                            </a>
                            <div class="collapse" id="Blog" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="page.php?pg=Blog">New</a>
                                    <a class="nav-link" href="page.php?pg=view_Blog">View</a>
                                    
                                         <a class="nav-link" href="page.php?pg=view_insideblog">More</a>
                                </nav>
                            </div>
                            
 
                            
                            
                         
                            
                            
                               
                            <a class="nav-link" href="page.php?pg=setting">
                                <div class="sb-nav-link-icon"><i class="fa fa-gear fa-spin"></i></div>
                                Setting
                            </a>
                            
                            
                                  
                             
                             
                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Logout
                            </a>

                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Admin
                    </div>
                </nav>
            </div>