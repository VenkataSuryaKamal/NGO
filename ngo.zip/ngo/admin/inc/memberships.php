<?php


// Check if user is not logged in, redirect to login page

// Include your database connection
include 'inc/db1.php';

// Retrieve all details of volunteers from the database
$sql = "SELECT * FROM volunteer_application_form";
$stmt = $dbh->prepare($sql);
$stmt->execute();
$volunteers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Details</title>
    <!-- Add your CSS links here -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

</head>

<body>

    <div class="container">
        <h2>Volunteer Details</h2>
        <button onclick="exportToExcel()" class="btn btn-primary" style="float: right;">Export to Excel</button>


        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                       
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Mobile Number</th>
                                <th>Blood Group</th>
                                <th>Date of Birth</th>
                                <th>Email</th>
                                <th>Emergency Contact Name</th>
                                <th>Emergency Contact Relationship</th>
                                <th>Emergency Contact Phone Number</th>
                                <th>Emergency Contact Email</th>
                                <th>Previous Volunteer Experience</th>
                                <th>Experience Details</th>
                                <th>Volunteer Motivation</th>
                                <th>Skills</th>
                                <th>Availability</th>
                                <th>Declaration</th>
                                <th>Membership Start Date</th>
                                <th>Membership Expiry Date</th>
                                <th>Membership Title</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($volunteers as $volunteer): ?>
                                <tr>
                                    <td><?php echo $volunteer['id']; ?></td>
                                    <td><?php echo $volunteer['name']; ?></td>
                                    <td><?php echo $volunteer['address']; ?></td>
                                    <td><?php echo $volunteer['mobile_number']; ?></td>
                                    <td><?php echo $volunteer['blood_group']; ?></td>
                                    <td><?php echo $volunteer['date_of_birth']; ?></td>
                                    <td><?php echo $volunteer['email']; ?></td>
                                    <td><?php echo $volunteer['emergency_contact_name']; ?></td>
                                    <td><?php echo $volunteer['emergency_contact_relationship']; ?></td>
                                    <td><?php echo $volunteer['emergency_contact_phone_number']; ?></td>
                                    <td><?php echo $volunteer['emergency_contact_email']; ?></td>
                                    <td><?php echo $volunteer['previous_volunteer_experience']; ?></td>
                                    <td><?php echo $volunteer['experience_details']; ?></td>
                                    <td><?php echo $volunteer['volunteer_motivation']; ?></td>
                                    <td><?php echo $volunteer['skills']; ?></td>
                                    <td><?php echo $volunteer['availability']; ?></td>
                                    <td><?php echo $volunteer['declaration']; ?></td>
                                    <td><?php echo $volunteer['membership_start_date']; ?></td>
                                    <td><?php echo $volunteer['membership_expiry_date']; ?></td>
                                    <td><?php echo $volunteer['membership_title']; ?></td>
                                    <td><?php echo $volunteer['status']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    function exportToExcel() {
        let table = document.getElementById("dataTable");
        let html = table.outerHTML;
        let url = 'data:application/vnd.ms-excel,' + escape(html); // Data URI
        let link = document.createElement("a");
        link.href = url;
        link.download = "volunteer_details.xls";
        link.click();
    }
</script>

</html>
