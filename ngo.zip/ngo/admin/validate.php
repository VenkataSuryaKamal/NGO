<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>

<script>

function goForward()
  {
  window.history.forward();
  
  }
</script>
</head>
<body>
<form name='myform' action='page.php?pg=home' method='post'>
<input type="hidden" name="T" value="20Ad*jdjh">
</form>
<script type='text/javascript'>

  document.myform.submit();

</script>
</body></html>