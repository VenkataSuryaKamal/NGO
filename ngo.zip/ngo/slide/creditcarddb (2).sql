-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2024 at 05:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `creditcarddb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `bank_name` varchar(50) DEFAULT NULL,
  `cardname` varchar(50) DEFAULT NULL,
  `cardnumber` varchar(16) NOT NULL,
  `expiration_date` varchar(50) DEFAULT NULL,
  `cvv` varchar(3) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`bank_name`, `cardname`, `cardnumber`, `expiration_date`, `cvv`, `password`, `email`, `phone`) VALUES
('Bank 1', 'attada vyshnavi', '1122113344567894', '2024-03', '123', 'Vineetha@123', 'jsv.sridevi@gmail.com', '7095031154'),
('Bank 1', 'jsv sridevi', '1122334455667787', '2024-03', '123', 'Sree@123', 'jsv.sreedevi@gmail.com', '7095031154'),
('Bank 3', '1234123412341234', '1234123412341223', '2024-12', '123', 'Yaswanth@1', '20nu1a0517@nsrit.edu.in', '9949801812'),
('Bank 1', 'bhargav', '1234123412341234', '2024-12', '123', 'Yaswanth@1', 'bhargavyaswanth@gmail.com', '7075739174');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `amount` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `myemail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`amount`, `email`, `myemail`) VALUES
('56000', 'jsv.sridevi@gmail.com', 'jsv.sridevi@gmail.com'),
('56000', 'jsv.sridevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sridevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5', 'jsv.sreedevi@gmail.com', ''),
('5', 'jsv.sreedevi@gmail.com', ''),
('5', 'jsv.sreedevi@gmail.com', ''),
('5', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sridevi@gmail.com', ''),
('5000', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sridevi@gmail.com', 'jsv.sreedevi@gmail.com'),
('5000', 'jsv.sridevi@gmail.com', 'jsv.sridevi@gmail.com'),
('5000', 'jsv.sreedevi@gmail.com', 'jsv.sridevi@gmail.com'),
('14', '20nu1a0517@nsrit.edu.in', ''),
('35', '20nu1a0517@nsrit.edu.in', ''),
('50', 'bhargavyaswanth@gmail.com', ''),
('40', 'bhargavyaswanth@gmail.com', ''),
('235', '20nu1a0517@nsrit.edu.in', 'bhargavyaswanth@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `phone` int(10) NOT NULL,
  `BankName` varchar(30) NOT NULL,
  `receiverEmail` varchar(30) NOT NULL,
  `amount` int(5) NOT NULL,
  `cardname` varchar(50) NOT NULL,
  `cardnumber` int(16) NOT NULL,
  `cvv` int(3) NOT NULL,
  `expirationdate` int(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`phone`, `BankName`, `receiverEmail`, `amount`, `cardname`, `cardnumber`, `cvv`, `expirationdate`, `email`, `status`) VALUES
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, '', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', 'jsv.sreedevi@gmail.com', 5000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'jsv.sridevi@gmail.com', 50000, 'attada vyshnavi', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', '20nu1a0517@nsrit.edu.in', 40, 'bhargav', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 1', '20nu1a0517@nsrit.edu.in', 40, 'bhargav', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'bhargavyaswanth@gmail.com', 40, 'bhargav', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'bhargavyaswanth@gmail.com', 40, 'bhargav', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'bhargavyaswanth@gmail.com', 40, '1234123412341234', 123, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'bhargavyaswanth@gmail.com', 40, '1234123412341234', 123, 123, 2024, '0', '0'),
(2147483647, 'Bank 2', 'bhargavyaswanth@gmail.com', 40, '1234123412341234', 123, 123, 2024, '0', '0'),
(2147483647, 'Bank 4', 'bhargavyaswanth@gmail.com', 45, '1234123412341234', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 5', 'bhargavyaswanth@gmail.com', 34, '1234123412341234', 2147483647, 123, 2024, '0', '0'),
(2147483647, 'Bank 5', 'bhargavyaswanth@gmail.com', 34, '1234123412341234', 2147483647, 123, 2024, 'bhargavyaswanth@gmail.com', 'Valid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`cardnumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
