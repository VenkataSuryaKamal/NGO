<?php
ob_start(); 
session_start();
include 'admin/inc/db.php';

        //echo "update super set status='1' where mobile='$_SESSION[u_id]'";
        $stmt = $dbh->prepare("update super set status='1' where mobile='$_SESSION[u_id]'");
        $stmt->execute();
       header("location: donate_home.php");
?>