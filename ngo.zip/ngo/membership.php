<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "educate";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store user data
$userData = array();

// Check if user is logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    // Fetch user data from the database
    $userId = $_SESSION["id"]; // Assuming you store user's ID in session after login
    $sql = "SELECT name, mobile_number, address FROM users WHERE id = $userId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found, fetch and store data
        $userData = $result->fetch_assoc();
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Active 24x7 Charitable Trust Volunteer Application Form</title>
<style>body {
  font-family: sans-serif;
  margin: 0;
  padding: 0;
}

.container {
  width: 700px; /* Adjust width as needed */
  margin: 50px auto;
  border: 1px solid #ccc;
  padding: 20px;
  border-radius: 5px;
}

h1,
p {
  text-align: center;
}

h1 {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

.row {
  margin-bottom: 15px;
}

select,
input[type="text"],
input[type="email"],
input[type="tel"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

textarea {
  width: 100%;
  height: 100px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

.radio-container {
  display: flex;
  align-items: center; /* Radio buttons align vertically */
  margin-bottom: 15px;
}

.radio-container label {
  margin-right: 10px;
}

.radio-container input[type="radio"] {
  margin-right: 5px;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}

button:hover {
  background-color: #3e8e41;
}

h2 {
  margin-top: 30px; /* Spacing between sections */
  margin-bottom: 15px;
  border-bottom: 1px solid #ccc;
  padding-bottom: 10px;
}

.declaration {
  display: flex;
  align-items: center;
}

.declaration input[type="checkbox"] {
  margin-right: 10px;
}
.s1{
  padding-left:80px;
}
.row1 {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
  }
  
  label {
    flex: 1;
    font-weight: bold;
  }
  
  select {
    flex: 3;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  
  .cost {
    margin-left: 200px;
    font-weight: bold;
  }
  
</style>
</head>
<body>
  <div class="container">
    <h1>ACTIVE 24X7 CHARITABLE TRUST</h1>
    <h2>*FOR OFFICE USE*</h2>
  
    <p>*The information you provide will be stored in confidence under the provisions of the Data Protection Act. Your form will be held confidentially. Only authorized staff will have access to your information.*</p>
  
    <form action="submit_application.php" id="volunteer-application-form" method="post">
      <h2>Personal Details</h2>
      <div class="row">
        <label for="title">Title:</label>
        <select id="title" name="title" required>
          <option value="">Please Select</option>
          <option value="mr">Mr.</option>
          <option value="mrs">Mrs.</option>
          <option value="miss">Miss</option>
          <option value="ms">Ms</option>
        </select>
      </div>
      <div class="row">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div class="row">
        <label for="address">Address:</label>
        <textarea id="address" name="address" rows="4" cols="50" required></textarea>
      </div>
      <div class="row">
        <label for="mobile_number">Mobile No.:</label>
        <input type="tel" id="mobile_number" name="mobile_number" required>
      </div>
      <div class="row">
        <label for="blood_group">Blood Group:</label>
        <input type="text" id="blood_group" name="blood_group" required>
      </div>
      <div class="row">
        <label for="date_of_birth">Birth Date:</label>
        <input type="date" id="date_of_birth" name="date_of_birth" required>
      </div>
      <div class="row">
        <label for="email">E-Mail:</label>
        <input type="email" id="email" name="email" required>
      </div>
      
      <h2>Emergency Contact</h2>
      <div class="row">
        <label for="emergency_contact_name">Name:</label>
        <input type="text" id="emergency_contact_name" name="emergency_contact_name" required>
      </div>
      <div class="row">
        <label for="emergency_contact_relationship">Relationship:</label>
        <input type="text" id="emergency_contact_relationship" name="emergency_contact_relationship" required>
      </div>
      <div class="row">
        <label for="emergency_contact_phone_number">Telephone (Home/Cell):</label>
        <input type="tel" id="emergency_contact_phone_number" name="emergency_contact_phone_number" required>
      </div>
      <div class="row">
        <label for="emergency_contact_email">Email:</label>
        <input type="email" id="emergency_contact_email" name="emergency_contact_email" required>
      </div>
      <h2>Membership Details</h2>
      <div class="row1">
        <label for="title">Membership</label>
        <select id="membershipTitle" name="membershipTitle" required onchange="updateCost()">

          <option value="" data-cost="0">Please Select Membership</option>
          <option value="volunteer" data-cost="500">Volunteership (500/-)</option>
          <option value="membership" data-cost="1000">Membership (1000/-)</option>
          <option value="executive" data-cost="1500">Executive Membership (1500/-)</option>
          <option value="board" data-cost="2000">Board Membership (2000/-)</option>
        </select>
        <span id="membershipCost" class="cost">-</span>

      </div>
      <h2>Skills and Interests</h2>
      <div class="row">
        <label for="previous_volunteer_experience">Have you ever done any voluntary work before?</label>
        <br>
        <label for="yes_experience">Yes</label>
        <input type="radio" id="yes_experience" name="previous_volunteer_experience" value="yes">
        <label for="no_experience">No</label>
        <input type="radio" id="no_experience" name="previous_volunteer_experience" value="no">
      </div>
      <div class="row">
        <label for="experience_details">If yes, please tell us a little about the experience (optional):</label>
        <textarea id="experience_details" name="experience_details" rows="4" cols="50"></textarea>
      
      </div>
      <div class="row">
        <label for="volunteer_motivation">Why do you want to volunteer now? What has motivated you to get in touch with us?</label>
        <textarea id="volunteer_motivation" name="volunteer_motivation" rows="4" cols="50" required></textarea>
      </div>
      <div class="row">
        <label for="skills">Skills you can offer:</label>
        <textarea id="skills" name="skills" rows="4" cols="50" required></textarea>
      </div>
      
      <div class="row">
        <label for="availability">Availability (Days & Times):</label>
        
        <br>
        <label for="weekday_morning">Weekdays (Morning):</label>
        <input type="checkbox" id="weekday_morning" name="availability[]" value="weekday_morning">
        <label for="weekday_afternoon">Weekdays (Afternoon):</label>
        <input type="checkbox" id="weekday_afternoon" name="availability[]" value="weekday_afternoon">
        <label for="weekday_evening">Weekdays (Evening):</label>
        <input type="checkbox" id="weekday_evening" name="availability[]" value="weekday_evening">
        <br>
        <label for="weekend_morning">Weekends (Morning):</label>
        <input type="checkbox" id="weekend_morning" name="availability[]" value="weekend_morning">
        <label for="weekend_afternoon">Weekends (Afternoon):</label>
        <input type="checkbox" id="weekend_afternoon" name="availability[]" value="weekend_afternoon">
        <label for="weekend_evening">Weekends (Evening):</label>
        <input type="checkbox" id="weekend_evening" name="availability[]" value="weekend_evening">
      </div>
      <div class="row">
        <label for="skills">Any Thing You Want To Mention:</label>
        <textarea id="skills" name="skills" rows="4" cols="50" required></textarea>
      </div>
      <div class="row">
        <label for="declaration">Please confirm that you have read the volunteer handbook and agree to abide by the terms and conditions of volunteering with Active 24x7 Charitable Trust.</label>
        <br>
        <input type="checkbox" id="declaration" name="declaration" required>
        <label for="declaration">I agree</label>
      </div>
      
      <button type="submit">Submit Application</button>
    </form>
  </div>
  <script>function updateCost() {
    var selectElement = document.getElementById("membershipTitle");
    var costElement = document.getElementById("membershipCost");
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    var cost = selectedOption.getAttribute("data-cost");
    costElement.textContent = cost === "0" ? "Free" : "₹" + cost; // Use ₹ for Indian Rupee symbol
  }
  
  </script>
</body>

</html>