<?php
ob_start();
include 'admin/inc/db.php';
session_start();
if(isset($_POST['save'])) {      
    $name = str_replace("'","''", $_POST['name']);  
    $mobile = str_replace("'","''", $_POST['phone']);
    $email = str_replace("'","''", $_POST['email']);
    $wing = str_replace("'","''", $_POST['wing']); // Capture the selected wing
    $donate = str_replace("'","''", $_POST['donate']);
      
    $stmt = $dbh->prepare("INSERT INTO super (name, mobile, email, wing, donate, cdate) VALUES ('$name', '$mobile', '$email', '$wing', '$donate', CURDATE())");
    $stmt->execute();
    session_regenerate_id(); 
    $_SESSION["u_id"] = $mobile;
    header("location: donate_home.php");
}
?>
